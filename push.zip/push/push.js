var webPush = require('web-push');
 
const vapidKeys = {
   "publicKey": "BI1mkR2aJNrP_BByg18l_7D5Su_a7SsqTSvo6LSVCoX6jw-okg_2MhvWpfFO7pNnowMwXX1BdnmyOXZCdhxaQYE",
   "privateKey": "Q7EptsRbupq-H9ffDLuH_QlEm5QV6CCSzazZKpaoAug"
};
 
 
webPush.setVapidDetails(
   'mailto:example@yourdomain.org',
   vapidKeys.publicKey,
   vapidKeys.privateKey
)
var pushSubscription = {
   "endpoint": "https://fcm.googleapis.com/fcm/send/dbShBMlMMFI:APA91bHDeB-ijBeCeSVMrM6vdZpU8CYJtCsKilyBQ19LdKFaZlcmwc4tWBzCO1IwKwGMt6rqAjOdIY9pvIPRvLW5kiyKbBneCxOEGtq7raEYBoT6CmyAvbMsSzQyt1-wUWGENXu4Lr6-",
   "keys": {
       "p256dh": "BD2SRM/VFdx2N4rVecYWOXFd1/OvKn4ovKQbODE+3h4egPuP4kAqEqTOSVQlHEA+3Qk+F40xAQnHvFSglJHzW4Y=",
       "auth": "Tr9WznQUc0VROE5fK3NB3g=="
   }
};
var payload = 'Selamat! Aplikasi Anda sudah dapat menerima push notifikasi!';
 
var options = {
   gcmAPIKey: '329117623610',
   TTL: 60
};
webPush.sendNotification(
   pushSubscription,
   payload,
   options
);